#ifndef DELAY_H
#define DELAY_H

#include <stdint.h> // Include this header for uint32_t

void delay_ms(uint32_t milliseconds);

#endif /* DELAY_H */
